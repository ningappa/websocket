function ChatClient() {
    if (window.WebSocket) {
        transport = ChatClient.WebSocket
    } else {
        var transport = ChatClient.LongPoll
    }
    console.log(this);
    console.log(transport);
    transport.setup.call(this)
    console.log(this);
    this.subscribe = transport.subscribe
    this.publish = transport.publish
    this._configureListeners = transport._configureListeners

}

ChatClient.LongPoll = {
    subscribe: function (callback) {
        var longPoll = function () {
            $.ajax({
                method: 'GET',
                url: '/messages',
                success: function (data) {
                    callback(data)
                },
                complete: function () {
                    longPoll()
                },
                timeout: 30000
            })
        }
        longPoll()
    },
    publish: function (data) {
        $.post('/messages', data)
    }
}

ChatClient.WebSocket = {    
    setup: function () {
        this.socket = new WebSocket('wss://ningappa')
    },
    subscribe: function (callback) {
        this.socket.onmessage = function (event) {
            callback(JSON.parse(event.data))
        }
    },
    publish: function (data) {
        this.socket.send(JSON.stringify(data))
    },
    _configureListeners: function () {
        this.socket.onclose = function () {
            console.log(this);
        }
        this.socket.onerror = function (error) {
            console.log("error")
        }
        this.socket.onopen = function (error) {
            console.log("open")
        }
    }
}
